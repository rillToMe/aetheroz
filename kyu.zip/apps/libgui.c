// ============================================================
// apps/libgui.c — Kyuzen GUI Framework Implementation
//
// PENTING: FONT8x16_IMPLEMENTATION hanya boleh di-define SATU kali.
// Karena libgui.c mengimplementasikannya, app yang link libgui.o
// TIDAK BOLEH mendefinisikan FONT8x16_IMPLEMENTATION sendiri.
// ============================================================

#define FONT8x16_IMPLEMENTATION
#include "font8x16.h"
#include "libgui.h"
#include "userlib.h"
#include <stdint.h>

// ============================================================
// INTERNAL HELPERS
// ============================================================

static void _lgui_strncpy(char* dst, const char* src, int n) {
    int i = 0;
    while (i < n - 1 && src[i]) { dst[i] = src[i]; i++; }
    dst[i] = '\0';
}

static void _lgui_itoa(uint32_t n, char* buf) {
    if (n == 0) { buf[0] = '0'; buf[1] = '\0'; return; }
    char tmp[16]; int i = 0;
    while (n > 0) { tmp[i++] = '0' + (n % 10); n /= 10; }
    int j = 0;
    while (i > 0) buf[j++] = tmp[--i];
    buf[j] = '\0';
}

static void _lgui_strcat(char* dst, const char* src) {
    while (*dst) dst++;
    while (*src) *dst++ = *src++;
    *dst = '\0';
}

// Hitung panjang string
static int _lgui_strlen(const char* s) {
    int n = 0; while (s[n]) n++; return n;
}

// ============================================================
// CANVAS DRAWING — koordinat dalam canvas TOTAL
// (caller harus tambah GUI_TITLEBAR_H ke y untuk area isi)
// ============================================================

static void _lgui_fill_rect(gui_window_t* win, int x, int y, int w, int h, uint32_t color) {
    uint32_t solid = color | 0xFF000000;
    int W = (int)win->width;
    int H = (int)win->height;
    for (int py = y; py < y + h; py++) {
        for (int px = x; px < x + w; px++) {
            if (px >= 0 && px < W && py >= 0 && py < H)
                win->canvas[(py * W) + px] = solid;
        }
    }
}

static void _lgui_draw_char_abs(gui_window_t* win, char c, int x, int y, uint32_t color) {
    if (c < 0 || c > 127) return;
    const unsigned char* bitmap = font8x16[(int)(unsigned char)c];
    uint32_t solid = color | 0xFF000000;
    int W = (int)win->width;
    int H = (int)win->height;
    for (int row = 0; row < 16; row++) {
        for (int col = 0; col < 8; col++) {
            if (bitmap[row] & (0x80 >> col)) {
                int px = x + col, py = y + row;
                if (px >= 0 && px < W && py >= 0 && py < H)
                    win->canvas[(py * W) + px] = solid;
            }
        }
    }
}

static void _lgui_draw_string_abs(gui_window_t* win, const char* str, int x, int y, uint32_t color) {
    int cx = x, cy = y;
    for (int i = 0; str[i]; i++) {
        if (str[i] == '\n') { cy += 16; cx = x; }
        else { _lgui_draw_char_abs(win, str[i], cx, cy, color); cx += 8; }
    }
}

// ============================================================
// RENDER TITLE BAR (dipanggil otomatis di setiap flush)
// ============================================================

static void _lgui_draw_titlebar(gui_window_t* win) {
    int W = (int)win->width;

    // Background title bar
    _lgui_fill_rect(win, 0, 0, W, GUI_TITLEBAR_H, GUI_TITLEBAR_COLOR);

    // Close button merah di kanan
    _lgui_fill_rect(win, W - GUI_CLOSE_BTN_W, 0, GUI_CLOSE_BTN_W, GUI_TITLEBAR_H, GUI_CLOSE_COLOR);
    _lgui_draw_string_abs(win, "X", W - GUI_CLOSE_BTN_W + 14, 7, 0xFFFFFF);

    // Judul window di kiri
    _lgui_draw_string_abs(win, win->title, 10, 7, 0xFFFFFF);
}

// ============================================================
// PUBLIC API
// ============================================================

gui_window_t* gui_create_window(const char* title, uint32_t width, uint32_t height) {
    gui_window_t* win = (gui_window_t*)sys_alloc(sizeof(gui_window_t));
    if (!win) return 0;

    win->canvas = (uint32_t*)sys_alloc(width * height * 4);
    if (!win->canvas) { sys_free(win); return 0; }

    win->width    = width;
    win->height   = height;
    win->inner_w  = width;
    win->inner_h  = height - GUI_TITLEBAR_H;
    win->is_running = 1;
    win->mouse_x  = 0;
    win->mouse_y  = 0;
    win->rel_x    = 0;
    win->rel_y    = 0;
    win->on_render = 0;
    _lgui_strncpy(win->title, title, 64);

    // Buat window via KWM (posisi default: 100, 80)
    win->win_id = sys_kwm_create_window(100, 80, width, height);
    if (win->win_id < 0) {
        sys_free(win->canvas);
        sys_free(win);
        return 0;
    }

    // Gambar frame awal
    _lgui_fill_rect(win, 0, GUI_TITLEBAR_H, (int)width, (int)height - GUI_TITLEBAR_H, 0xF5F5F5);
    _lgui_draw_titlebar(win);
    sys_kwm_update_window(win->win_id, win->canvas);

    return win;
}

void gui_set_render(gui_window_t* win, gui_render_fn fn) {
    if (win) win->on_render = fn;
}

void gui_flush(gui_window_t* win) {
    if (!win) return;
    _lgui_draw_titlebar(win); // Title bar selalu fresh di atas rendering app
    sys_kwm_update_window(win->win_id, win->canvas);
}

void gui_destroy(gui_window_t* win) {
    if (!win) return;
    sys_kwm_destroy_window(win->win_id);
    sys_free(win->canvas);
    sys_free(win);
}

// ============================================================
// EVENT LOOP UTAMA
// ============================================================

void gui_mainloop(gui_window_t* win) {
    if (!win) return;
    kyuzen_event_t ev;

    while (win->is_running) {
        if (sys_get_event(&ev)) {

            // --- Pergerakan Mouse ---
            if (ev.type == EVENT_MOUSE_MOVE) {
                win->mouse_x = ev.param1;
                win->mouse_y = ev.param2;

                // Hitung koordinat relatif terhadap window origin
                int wx = 0, wy = 0;
                sys_get_window_pos(win->win_id, &wx, &wy);
                win->rel_x = win->mouse_x - wx;
                win->rel_y = win->mouse_y - wy - GUI_TITLEBAR_H;
            }

            // --- Klik Kiri Ditekan ---
            if (ev.type == EVENT_MOUSE_CLICK && ev.param1 == 0 && ev.param2 == 1) {
                // Sinkronkan posisi
                if (ev.param3 != 0) win->mouse_x = ev.param3;

                int wx = 0, wy = 0;
                sys_get_window_pos(win->win_id, &wx, &wy);
                win->rel_x = win->mouse_x - wx;
                win->rel_y = win->mouse_y - wy - GUI_TITLEBAR_H;

                // Cek: apakah klik mengenai tombol Close (X)?
                // Close button = [width-GUI_CLOSE_BTN_W .. width] × [0 .. GUI_TITLEBAR_H]
                // Koordinat relatif terhadap window (termasuk title bar):
                int rel_full_x = win->mouse_x - wx;  // relatif dari kiri window
                int rel_full_y = win->mouse_y - wy;  // relatif dari atas window (termasuk titlebar)

                if (rel_full_x >= (int)win->width - GUI_CLOSE_BTN_W &&
                    rel_full_x <  (int)win->width &&
                    rel_full_y >= 0 &&
                    rel_full_y <  GUI_TITLEBAR_H) {
                    win->is_running = 0; // Tutup window
                    break;
                }
            }

            // --- Keyboard ESC ---
            if (ev.type == EVENT_KEY_PRESS && ev.param1 == 27) {
                win->is_running = 0;
                break;
            }
        }

        // Panggil render callback app (jika ada)
        if (win->on_render) {
            // Bersihkan area isi dulu (app bisa override dengan warna mereka sendiri)
            win->on_render(win);
            gui_flush(win);
        }

        sys_yield();
    }
}

// ============================================================
// DRAWING API — koordinat RELATIF ke area isi (di bawah titlebar)
// ============================================================

void gui_draw_rect(gui_window_t* win, int x, int y, int w, int h, uint32_t color) {
    if (!win) return;
    // Geser y ke bawah title bar
    _lgui_fill_rect(win, x, y + GUI_TITLEBAR_H, w, h, color);
}

void gui_draw_char(gui_window_t* win, char c, int x, int y, uint32_t color) {
    if (!win) return;
    _lgui_draw_char_abs(win, c, x, y + GUI_TITLEBAR_H, color);
}

void gui_draw_text(gui_window_t* win, const char* text, int x, int y, uint32_t color) {
    if (!win) return;
    _lgui_draw_string_abs(win, text, x, y + GUI_TITLEBAR_H, color);
}

void gui_draw_label_num(gui_window_t* win, const char* label, uint32_t num,
                        const char* suffix, int x, int y, uint32_t color) {
    char buf[128];
    _lgui_strncpy(buf, label, 80);
    char num_str[16];
    _lgui_itoa(num, num_str);
    _lgui_strcat(buf, num_str);
    if (suffix && suffix[0]) _lgui_strcat(buf, suffix);
    gui_draw_text(win, buf, x, y, color);
}

void gui_draw_bar(gui_window_t* win, int x, int y, int w, int h,
                  uint32_t value, uint32_t max_value, uint32_t bar_color) {
    if (!win || max_value == 0) return;
    // Background bar (abu-abu gelap)
    gui_draw_rect(win, x, y, w, h, 0x333333);
    // Isi bar
    int filled = (int)((value * (uint32_t)w) / max_value);
    if (filled > w) filled = w;
    if (filled > 0) gui_draw_rect(win, x, y, filled, h, bar_color);
}
